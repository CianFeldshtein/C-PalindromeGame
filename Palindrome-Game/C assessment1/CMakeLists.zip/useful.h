//
// Created by Cian on 09/03/2018.
//
#ifndef USEFUL_H_INCLUDED
#define USEFUL_H_INCLUDED
//--------------------------------------------------
// DATA TYPES DEFINITIONS
//--------------------------------------------------
enum Bool { False, True };
typedef enum Bool boolean;

char my_get_char();

#endif // USEFUL_H_INCLUDED